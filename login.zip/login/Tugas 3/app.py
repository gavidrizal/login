from flask import Flask, render_template, request, redirect, url_for, flash

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Needed for flash messages

# Hardcoded credentials (username: user, password: pass)
USERNAME = 'ganteng'
PASSWORD = '1234'

@app.route('/')
def index():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    
    if username == USERNAME and password == PASSWORD:
        return redirect(url_for('beranda'))
    else:
        flash('Username atau password salah. Silahkan coba lagi.')
        return redirect(url_for('index'))

@app.route("/beranda")
def beranda():
    return render_template('beranda.html')

@app.route("/jados")
def jados():
    return render_template('jados.html')

@app.route("/jamas")
def jamas():
    return render_template('jamas.html')

@app.route("/judos")
def judos():
    return render_template('judos.html')

@app.route("/jumas")
def jumas():
    return render_template('jumas.html')

if __name__ == '__main__':
    app.run(debug=True)